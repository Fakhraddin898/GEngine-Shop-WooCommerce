<?php
/*
Plugin Name: G-Engine AZN Mağaza (Yeni Dizayn)
Description: G-Engine API inteqrasiyası - Yeni mavi dizayn
Version: 3.2-AZ-IMPROVED
Author: Faxri & Manus
*/

if (!defined('ABSPATH')) { exit; }

class GEngineAZNShop {

    private $api_url = 'https://api.g-engine.net/v2.1';
    private $azn_rate = 1.7;

    public function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_init', array($this, 'settings'));
        add_action('init', array($this, 'register_product_post_type'));
        
        add_shortcode('gengine_shop', array($this, 'shop_shortcode'));
        add_shortcode('gengine_recharge', array($this, 'recharge_shortcode'));
        add_shortcode('gengine_gift_cards', array($this, 'gift_cards_shortcode'));
        
        add_action('wp_ajax_gengine_get_service', array($this, 'ajax_get_service'));
        add_action('wp_ajax_nopriv_gengine_get_service', array($this, 'ajax_get_service'));
        add_action('wp_ajax_gengine_add_to_cart', array($this, 'ajax_add_to_cart'));
        add_action('wp_ajax_nopriv_gengine_add_to_cart', array($this, 'ajax_add_to_cart'));
        add_action('wp_ajax_gengine_sync_products', array($this, 'ajax_sync_products'));
        add_action('wp_ajax_gengine_save_image', array($this, 'ajax_save_image'));

        add_filter('woocommerce_get_item_data', array($this, 'get_item_data'), 10, 2);
        add_action('woocommerce_checkout_create_order_line_item', array($this, 'add_order_item_meta'), 10, 4);
        add_action('woocommerce_before_calculate_totals', array($this, 'before_calculate_totals'), 10, 1);
        add_filter('woocommerce_cart_item_name', array($this, 'change_cart_item_name'), 10, 3);
        add_filter('woocommerce_cart_item_thumbnail', array($this, 'cart_item_thumbnail'), 10, 3);
        add_filter('woocommerce_cart_item_removed_title', array($this, 'change_removed_item_name'), 10, 2);
        
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        
        // Модификация поиска для включения кастомных постов
        add_filter('pre_get_posts', array($this, 'include_products_in_search'));
        
        // Изменение контента постов товаров
        add_filter('the_content', array($this, 'gengine_product_content'));

        // G-Engine API Sifariş inteqrasiyası
        add_action('woocommerce_order_status_processing', array($this, 'process_gengine_order'), 10, 1);
        add_action('woocommerce_order_status_completed', array($this, 'process_gengine_order'), 10, 1);
    }
    
    public function gengine_product_content($content) {
        if (is_singular('gengine_product') && in_the_loop() && is_main_query()) {
            global $post;
            $gengine_id = get_post_meta($post->ID, '_gengine_id', true);
            $gengine_type = get_post_meta($post->ID, '_gengine_type', true);
            $gengine_image = get_post_meta($post->ID, '_gengine_image', true);
            $gengine_price = get_post_meta($post->ID, '_gengine_price', true);
            
            $custom_content = '<div class="gengine-product-single">';
            
            if ($gengine_image) {
                $custom_content .= '<div class="gengine-product-image"><img src="' . esc_url($gengine_image) . '" alt="' . esc_attr($post->post_title) . '"></div>';
            }
            
            $custom_content .= '<div class="gengine-product-info">';
            $custom_content .= $content;
            
            if ($gengine_price > 0) {
                $custom_content .= '<p class="gengine-price">Qiymət: <strong>' . number_format($gengine_price, 2) . ' AZN</strong>-dən başlayır</p>';
            }
            
            $custom_content .= '<div class="gengine-product-button">';
            $custom_content .= '<button class="gengine-buy-now-btn" data-id="' . esc_attr($gengine_id) . '" data-source="' . esc_attr($gengine_type) . '">INDI AL</button>';
            $custom_content .= '</div>';
            $custom_content .= '</div></div>';
            
            // Добавляем модальное окно и скрипты
            $custom_content .= '<div id="gengine-modal" class="gengine-modal"><div class="gengine-modal-content"><span class="gengine-close">&times;</span><div id="gengine-modal-body"></div></div></div>';
            $custom_content .= $this->styles();
            $custom_content .= $this->scripts();
            $custom_content .= '<style>
                .gengine-product-single { max-width: 800px; margin: 0 auto; }
                .gengine-product-image { text-align: center; margin-bottom: 30px; }
                .gengine-product-image img { max-width: 300px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
                .gengine-product-info { background: #f8f9fa; padding: 30px; border-radius: 12px; }
                .gengine-price { font-size: 20px; color: #0067ed; margin: 20px 0; }
                .gengine-buy-now-btn { background: #0067ed; color: white; border: none; padding: 15px 40px; font-size: 16px; font-weight: 700; border-radius: 8px; cursor: pointer; text-transform: uppercase; transition: 0.3s; }
                .gengine-buy-now-btn:hover { background: #0052bd; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,103,237,0.3); }
            </style>';
            $custom_content .= '<script>
                jQuery(document).ready(function($) {
                    $(".gengine-buy-now-btn").click(function() {
                        var id = $(this).data("id");
                        var source = $(this).data("source");
                        
                        $("#gengine-modal").show();
                        $("#gengine-modal-body").html("<p style=\'text-align:center;padding:50px;\'>Yüklənir...</p>");
                        
                        $.post("' . admin_url('admin-ajax.php') . '", { 
                            action: "gengine_get_service", 
                            id: id, 
                            source: source 
                        }, function(res) {
                            if(res.success) { 
                                $("#gengine-modal-body").html(res.data); 
                            } else { 
                                $("#gengine-modal-body").html("<p style=\'padding:20px;color:red;\'>" + res.data + "</p>"); 
                            }
                        });
                    });
                });
            </script>';
            
            return $custom_content;
        }
        return $content;
    }
    
    public function register_product_post_type() {
        register_post_type('gengine_product', array(
            'labels' => array(
                'name' => 'G-Engine Məhsullar',
                'singular_name' => 'G-Engine Məhsul'
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'gengine-products'),
            'supports' => array('title', 'editor', 'thumbnail'),
            'show_in_search' => true,
            'exclude_from_search' => false,
            'publicly_queryable' => true,
            'menu_icon' => 'dashicons-cart'
        ));
    }
    
    public function include_products_in_search($query) {
        if (!is_admin() && $query->is_search() && $query->is_main_query()) {
            $post_types = $query->get('post_type');
            if (empty($post_types)) {
                $post_types = array('post', 'page', 'gengine_product');
            } elseif (is_array($post_types)) {
                $post_types[] = 'gengine_product';
            }
            $query->set('post_type', $post_types);
        }
        return $query;
    }

    public function admin_assets($hook) {
        if ('toplevel_page_gengine-azn' !== $hook) return;
        wp_enqueue_media();
    }

    public function menu() {
        add_menu_page('G-Engine AZN', 'G-Engine AZN', 'manage_options', 'gengine-azn', array($this, 'settings_page'));
    }

    public function settings() {
        register_setting('gengine_azn_group', 'gengine_api_key');
        register_setting('gengine_azn_group', 'gengine_markup');
        register_setting('gengine_azn_group', 'gengine_custom_images', array($this, 'sanitize_array'));
        register_setting('gengine_azn_group', 'gengine_exchange_api_key');
        register_setting('gengine_azn_group', 'gengine_fake_discount');
        register_setting('gengine_azn_group', 'gengine_smart_markups', array($this, 'sanitize_array'));
        register_setting('gengine_azn_group', 'gengine_tg_token');
        register_setting('gengine_azn_group', 'gengine_tg_chatid');
    }
    
    public function sanitize_array($input) {
        if (!is_array($input)) return array();
        return $input; // Просто возвращаем массив, WP сам его сериализует
    }

    public function settings_page() {
        $custom_images = get_option('gengine_custom_images', array());
        if (!is_array($custom_images)) $custom_images = array();
        
        $api_key = get_option('gengine_api_key');
        
        $recharge_items = $this->get_all_items('/recharge/services');
        $gift_items = $this->get_all_items('/shop/products');

        $all_items = array_merge($recharge_items, $gift_items);
        ?>
        <div class="wrap">
            <h1>G-Engine AZN Parametrlər (v3.2-AZ-IMPROVED)</h1>
            
            <?php 
            // G-Engine Balans məlumatı
            $balance_data = $this->request('/users/balance');
            if ($balance_data && isset($balance_data['success']) && $balance_data['success']): 
                $b = $balance_data['data'];
            ?>
            <div class="notice notice-success" style="border-left-color: #28a745; padding: 15px;">
                <h3 style="margin: 0 0 10px 0;">💰 G-Engine Balans</h3>
                <p style="font-size: 16px; margin: 0;">
                    Balans: <strong><?php echo $b['balance']; ?> <?php echo $b['currency']; ?></strong> | 
                    Keşbek: <strong><?php echo $b['cashback']; ?> <?php echo $b['currency']; ?></strong>
                </p>
            </div>
            <?php endif; ?>

            <div class="notice notice-info">
                <p><strong>Kataloq statusu:</strong></p>
                <ul>
                    <li>Birbaşa artırımlar: <?php echo count($recharge_items); ?> ədəd</li>
                    <li>Hədiyyə kartları: <?php echo count($gift_items); ?> ədəd</li>
                </ul>
                <?php if (empty($gift_items) && !empty($api_key)): ?>
                    <p style="color: #d63638;"><strong>⚠️ Hədiyyə kartları tapılmadı!</strong> Yoxlayın:</p>
                    <ul>
                        <li>API açarı /shop/products-a giriş hüququna malikdir</li>
                        <li>G-Engine kataloqunda hədiyyə kartları var</li>
                        <li>Detallar üçün PHP error log-a baxın</li>
                    </ul>
                <?php endif; ?>
                
                <?php 
                // Показываем текущий курс AZN
                $current_rate = $this->get_azn_rate_with_protection();
                $exchange_api_key = get_option('gengine_exchange_api_key');
                ?>
                <p style="margin-top: 15px; padding: 10px; background: #e8f2ff; border-radius: 6px;">
                    <strong>💱 Cari AZN kursu:</strong> 1 USD = <strong style="color: #0067ed;"><?php echo number_format($current_rate, 4); ?> AZN</strong>
                    <?php if (empty($exchange_api_key)): ?>
                        <br><small style="color: #666;">⚠️ Exchange API açarı yoxdur, sabit 1.7 istifadə olunur</small>
                    <?php elseif ($current_rate == 1.7): ?>
                        <br><small style="color: #f39c12;">⚡ API kursu 1.65-dən aşağıdır, mühafizə 1.7 istifadə olunur</small>
                    <?php else: ?>
                        <br><small style="color: #28a745;">✓ API-dən canlı kurs istifadə olunur</small>
                    <?php endif; ?>
                </p>
            </div>
            
            <div class="notice notice-warning" style="border-left-color: #0067ed;">
                <h3 style="margin-top: 10px;">🔍 Sayt axtarışında görünmə</h3>
                <p>Məhsullarınızın saytın axtarış sistemi vasitəsilə tapılması üçün onları sinxronlaşdırın.</p>
                <button type="button" id="gengine-sync-btn" class="button button-primary button-large">
                    📥 Məhsulları Sinxronlaşdır
                </button>
                <span id="gengine-sync-status" style="margin-left: 15px; font-weight: 600;"></span>
                <p style="margin-top: 10px; font-size: 13px; color: #666;">
                    <strong>Qeyd:</strong> Bu, bütün G-Engine məhsullarını WordPress postları kimi yaradacaq ki, 
                    onlar saytın axtarış sistemi və SEO alətləri tərəfindən tapıla bilsin.
                </p>
            </div>

            <form method="post" action="options.php">
                <?php settings_fields('gengine_azn_group'); ?>
                <table class="form-table">
                    <tr><th>API Açarı (G-Engine)</th><td><input type="text" name="gengine_api_key" value="<?php echo esc_attr($api_key); ?>" style="width:400px"></td></tr>
                    <tr><th>Exchange Rate API Key</th><td><input type="text" name="gengine_exchange_api_key" value="<?php echo esc_attr(get_option('gengine_exchange_api_key')); ?>" style="width:400px"><br><small>exchangerate-api.com üçün API açarı</small></td></tr>
                    <tr><th>Marja (%)</th><td><input type="number" name="gengine_markup" value="<?php echo esc_attr(get_option('gengine_markup', 15)); ?>"><br><small>Sadə marja. Ağıllı marjalar aktivdirsə, bu istifadə olunmayacaq.</small></td></tr>
                    <tr><th>Feyк Endirim (%)</th><td><input type="number" name="gengine_fake_discount" value="<?php echo esc_attr(get_option('gengine_fake_discount', 0)); ?>" min="0" max="90"><br><small>Məs: 30 daxil etsəniz, qiymət 100 AZN-dirsə, köhnə qiymət 143 AZN göstəriləcək (0 = deaktiv)</small></td></tr>
                </table>
                
                <hr>
                <h2>📢 Telegram Bildirişləri</h2>
                <p>Sifarişlər və API xətaları haqqında Telegram-da bildiriş alın.</p>
                <table class="form-table">
                    <tr>
                        <th>Telegram Bot Token</th>
                        <td><input type="text" name="gengine_tg_token" value="<?php echo esc_attr(get_option('gengine_tg_token')); ?>" style="width:400px" placeholder="5555555555:AA..."><br><small>@BotFather-dan alınan token</small></td>
                    </tr>
                    <tr>
                        <th>Telegram Chat ID</th>
                        <td><input type="text" name="gengine_tg_chatid" value="<?php echo esc_attr(get_option('gengine_tg_chatid')); ?>" style="width:400px" placeholder="123456789"><br><small>Bildirişlərin göndəriləcəyi ID (şəxsi və ya qrup)</small></td>
                    </tr>
                </table>
                
                <hr>
                <h2>💡 Ağıllı Marjalar</h2>
                <p>Qiymət diapazonlarına görə fərqli marjalar təyin edin. Boş qoyun sadə marja istifadə etmək üçün.</p>
                <table class="widefat" style="max-width: 600px;">
                    <thead>
                        <tr>
                            <th>Min Qiymət (USD)</th>
                            <th>Max Qiymət (USD)</th>
                            <th>Marja (%)</th>
                        </tr>
                    </thead>
                    <tbody id="smart-markups-table">
                        <?php 
                        $smart_markups = get_option('gengine_smart_markups', array());
                        if (empty($smart_markups)) {
                            $smart_markups = array(array('min' => '', 'max' => '', 'markup' => ''));
                        }
                        if (is_array($smart_markups)) {
                            foreach ($smart_markups as $index => $range): 
                                // Проверка на корректность данных в строке
                                $min = isset($range['min']) ? $range['min'] : '';
                                $max = isset($range['max']) ? $range['max'] : '';
                                $markup = isset($range['markup']) ? $range['markup'] : '';
                        ?>
                        <tr class="markup-row">
                            <td><input type="number" name="gengine_smart_markups[<?php echo $index; ?>][min]" value="<?php echo esc_attr($min); ?>" placeholder="0" step="0.01" style="width: 100px;"></td>
                            <td><input type="number" name="gengine_smart_markups[<?php echo $index; ?>][max]" value="<?php echo esc_attr($max); ?>" placeholder="100" step="0.01" style="width: 100px;"></td>
                            <td><input type="number" name="gengine_smart_markups[<?php echo $index; ?>][markup]" value="<?php echo esc_attr($markup); ?>" placeholder="15" step="0.1" style="width: 100px;"> <button type="button" class="button remove-markup-row">Sil</button></td>
                        </tr>
                        <?php 
                            endforeach; 
                        }
                        ?>
                    </tbody>
                </table>
                <button type="button" id="add-markup-row" class="button">+ Diapazon Əlavə Et</button>
                <p style="margin-top: 10px; font-size: 13px; color: #666;"><strong>Nümunə:</strong> 0-10 USD = 20%, 10-50 USD = 15%, 50+ USD = 10%</p>
                
                <hr>
                <h2>Şəkil parametrləri</h2>
                <?php if (empty($all_items)): ?>
                    <div class="notice notice-warning">
                        <p><strong>Məhsullar tapılmadı!</strong> API Açarını və API-yə girişi yoxlayın.</p>
                    </div>
                <?php else: ?>
                <table class="widefat fixed" style="max-width: 800px;">
                    <thead><tr><th>Ad</th><th>Növ</th><th>Şəkil</th><th>Əməliyyat</th></tr></thead>
                    <tbody>
                        <?php 
                        if (is_array($all_items)) {
                            foreach ($all_items as $item): 
                                $is_gift = !isset($item['params']) && !isset($item['type']);
                            $type_label = $is_gift ? 'Hədiyyə Kartı' : 'Balans Artırımı';
                            $img_id = isset($custom_images[$item['id']]) ? $custom_images[$item['id']] : '';
                            $img_url = $img_id ? wp_get_attachment_image_url($img_id, 'thumbnail') : '';
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html($item['name']); ?></strong></td>
                                <td><?php echo $type_label; ?></td>
                                <td><div id="preview-<?php echo $item['id']; ?>" style="width: 50px; height: 50px; background: #eee; border: 1px solid #ccc; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                    <?php if ($img_url): ?><img src="<?php echo $img_url; ?>" style="max-width: 100%; max-height: 100%;"><?php else: ?><small>Yoxdur</small><?php endif; ?>
                                </div></td>
                                <td><button type="button" class="button gengine-upload-btn" data-id="<?php echo $item['id']; ?>">Seç</button> <button type="button" class="button gengine-clear-btn" data-id="<?php echo $item['id']; ?>">Təmizlə</button></td>
                            </tr>
                        <?php 
                            endforeach; 
                        }
                        ?>
                    </tbody>
                </table>
                <?php endif; ?>
                <?php submit_button('Yadda saxla'); ?>
            </form>
        </div>
        <script>
        jQuery(document).ready(function($){
            var markupIndex = <?php echo is_array($smart_markups) ? count($smart_markups) : 0; ?>;
            
            // Добавление новой строки диапазона
            $('#add-markup-row').click(function() {
                var newRow = '<tr class="markup-row">' +
                    '<td><input type="number" name="gengine_smart_markups[' + markupIndex + '][min]" placeholder="0" step="0.01" style="width: 100px;"></td>' +
                    '<td><input type="number" name="gengine_smart_markups[' + markupIndex + '][max]" placeholder="100" step="0.01" style="width: 100px;"></td>' +
                    '<td><input type="number" name="gengine_smart_markups[' + markupIndex + '][markup]" placeholder="15" step="0.1" style="width: 100px;"> <button type="button" class="button remove-markup-row">Sil</button></td>' +
                    '</tr>';
                $('#smart-markups-table').append(newRow);
                markupIndex++;
            });
            
            // Удаление строки
            $(document).on('click', '.remove-markup-row', function() {
                if ($('.markup-row').length > 1) {
                    $(this).closest('tr').remove();
                } else {
                    alert('Ən azı bir diapazon olmalıdır');
                }
            });
            
            // Синхронизация товаров
            $('#gengine-sync-btn').click(function() {
                var btn = $(this);
                var status = $('#gengine-sync-status');
                
                btn.prop('disabled', true).text('⏳ Sinxronlaşdırılır...');
                status.html('<span style="color: #0067ed;">Gözləyin...</span>');
                
                $.post(ajaxurl, {
                    action: 'gengine_sync_products'
                }, function(response) {
                    if (response.success) {
                        status.html('<span style="color: #28a745;">✓ ' + response.data + '</span>');
                        btn.text('✓ Tamamlandı');
                        setTimeout(function() {
                            btn.prop('disabled', false).text('📥 Məhsulları Sinxronlaşdır');
                            status.html('');
                        }, 3000);
                    } else {
                        status.html('<span style="color: #d63638;">✗ Xəta: ' + response.data + '</span>');
                        btn.prop('disabled', false).text('📥 Məhsulları Sinxronlaşdır');
                    }
                }).fail(function() {
                    status.html('<span style="color: #d63638;">✗ Server xətası</span>');
                    btn.prop('disabled', false).text('📥 Məhsulları Sinxronlaşdır');
                });
            });
            
            // Загрузка изображений (Мгновенное сохранение через AJAX)
            $('.gengine-upload-btn').click(function(e) {
                e.preventDefault();
                var id = $(this).data('id'), $btn = $(this);
                var frame = wp.media({ title: 'Şəkil seçin', multiple: false }).on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    $btn.prop('disabled', true).text('⏳...');
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'gengine_save_image',
                            product_id: id,
                            image_id: attachment.id,
                            nonce: '<?php echo wp_create_nonce('gengine_save_image'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                $('#preview-' + id).html('<img src="' + attachment.url + '" style="max-width: 100%; max-height: 100%;">');
                                $btn.css('background', '#28a745').css('color', '#fff').text('✅');
                                setTimeout(function(){ $btn.css('background', '').css('color', '').text('Seç'); }, 2000);
                            } else { 
                                alert('Xəta: ' + response.data); 
                                $btn.text('Seç');
                            }
                        },
                        error: function() {
                            alert('Server xətası baş verdi');
                            $btn.text('Seç');
                        },
                        complete: function() {
                            $btn.prop('disabled', false);
                        }
                    });
                }).open();
            });

            $('.gengine-clear-btn').click(function(){
                if(!confirm('Şəkli silmək istədiyinizə əminsiniz?')) return;
                
                var id = $(this).data('id'), $btn = $(this);
                $btn.prop('disabled', true).text('⏳...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'gengine_save_image',
                        product_id: id,
                        image_id: '',
                        nonce: '<?php echo wp_create_nonce('gengine_save_image'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#preview-' + id).html('<small>Yoxdur</small>');
                            $btn.text('Silindi');
                            setTimeout(function(){ $btn.text('Təmizlə'); }, 2000);
                        } else { 
                            alert('Xəta: ' + response.data); 
                            $btn.text('Təmizlə');
                        }
                    },
                    error: function() {
                        alert('Server xətası baş verdi');
                        $btn.text('Təmizlə');
                    },
                    complete: function() {
                        $btn.prop('disabled', false);
                    }
                });
            });
        });
        </script>
        <?php
    }

    private function send_telegram($message) {
        $token = get_option('gengine_tg_token');
        $chat_id = get_option('gengine_tg_chatid');
        if (!$token || !$chat_id) return;

        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        wp_remote_post($url, array(
            'body' => array(
                'chat_id' => $chat_id,
                'text' => $message,
                'parse_mode' => 'HTML'
            )
        ));
    }



    private function get_all_items($endpoint) {
        $all_items = array();
        $limit = 100;
        $offset = 0;
        
        while (true) {
            $sep = (strpos($endpoint, '?') !== false) ? '&' : '?';
            $data = $this->request("{$endpoint}{$sep}limit={$limit}&offset={$offset}");
            
            if (empty($data)) {
                error_log("G-Engine: $endpoint-dən boş cavab");
                break;
            }
            
            $items = array();
            if (isset($data['data']['items'])) {
                $items = $data['data']['items'];
            } elseif (isset($data['items'])) {
                $items = $data['items'];
            } elseif (isset($data['data']) && is_array($data['data']) && isset($data['data'][0])) {
                $items = $data['data'];
            } elseif (is_array($data) && isset($data[0])) {
                $items = $data;
            }
            
            if (empty($items)) {
                error_log("G-Engine: $endpoint-dən məhsul tapılmadı");
                break;
            }
            
            $all_items = array_merge($all_items, $items);
            
            if (count($items) < $limit) break;
            $offset += $limit;
            if ($offset > 3000) break;
        }
        
        error_log("G-Engine: $endpoint-dən " . count($all_items) . " məhsul əldə edildi");
        return $all_items;
    }

    private function azn_price($usd) {
        // Определяем наценку по диапазонам
        $markup = $this->get_smart_markup($usd);
        
        // Получаем курс для текущей валюты
        $rate = $this->get_exchange_rate();
        
        return round($usd * (1 + $markup / 100) * $rate, 2);
    }
    
    private function get_smart_markup($usd) {
        $smart_markups = get_option('gengine_smart_markups', array());
        
        // Если умные наценки не настроены или не массив, используем обычную
        if (!is_array($smart_markups) || empty($smart_markups)) {
            return floatval(get_option('gengine_markup', 15));
        }
        
        // Ищем подходящий диапазон
        foreach ($smart_markups as $range) {
            if (!is_array($range) || empty($range['markup'])) continue;
            
            $min = !empty($range['min']) ? floatval($range['min']) : 0;
            $max = !empty($range['max']) ? floatval($range['max']) : PHP_FLOAT_MAX;
            
            if ($usd >= $min && $usd <= $max) {
                return floatval($range['markup']);
            }
        }
        
        // Если не нашли диапазон, используем обычную наценку
        return floatval(get_option('gengine_markup', 15));
    }
    
    private function get_exchange_rate() {
        $currency = $this->get_current_currency();
        
        // Если AZN, используем встроенный курс с защитой минимума
        if ($currency === 'AZN') {
            return $this->get_azn_rate_with_protection();
        }
        
        // Получаем курс из API для других валют
        $api_key = get_option('gengine_exchange_api_key');
        if (empty($api_key)) {
            return $this->azn_rate; // Fallback на AZN
        }
        
        // Кэшируем курсы на 1 час
        $cache_key = 'gengine_rates_' . $currency;
        $cached_rate = get_transient($cache_key);
        
        if ($cached_rate !== false) {
            return floatval($cached_rate);
        }
        
        // Запрашиваем курсы
        $url = "https://v6.exchangerate-api.com/v6/{$api_key}/latest/USD";
        $response = wp_remote_get($url, array('timeout' => 10));
        
        if (is_wp_error($response)) {
            error_log('Exchange Rate API Error: ' . $response->get_error_message());
            return $this->azn_rate;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['conversion_rates'][$currency])) {
            $rate = floatval($data['conversion_rates'][$currency]);
            set_transient($cache_key, $rate, HOUR_IN_SECONDS);
            return $rate;
        }
        
        return $this->azn_rate; // Fallback
    }
    
    private function get_azn_rate_with_protection() {
        $api_key = get_option('gengine_exchange_api_key');
        
        // Если API ключ не настроен, используем фиксированный курс
        if (empty($api_key)) {
            error_log('G-Engine: Exchange API açarı yoxdur, 1.7 istifadə olunur');
            return $this->azn_rate; // 1.7
        }
        
        // Проверяем кэш
        $cache_key = 'gengine_azn_rate_protected';
        $cached_rate = get_transient($cache_key);
        
        if ($cached_rate !== false) {
            return floatval($cached_rate);
        }
        
        // Запрашиваем курс из API
        $url = "https://v6.exchangerate-api.com/v6/{$api_key}/latest/USD";
        $response = wp_remote_get($url, array('timeout' => 10));
        
        if (is_wp_error($response)) {
            error_log('G-Engine Exchange API Xətası: ' . $response->get_error_message() . ', 1.7 istifadə olunur');
            return $this->azn_rate;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['conversion_rates']['AZN'])) {
            error_log('G-Engine: AZN kursu tapılmadı, 1.7 istifadə olunur');
            return $this->azn_rate;
        }
        
        $api_rate = floatval($data['conversion_rates']['AZN']);
        
        // ЗАЩИТА: Если курс ниже 1.65, используем 1.7
        if ($api_rate < 1.65) {
            error_log("G-Engine: API kursu çox aşağıdır ({$api_rate}), 1.7 istifadə olunur");
            $final_rate = $this->azn_rate; // 1.7
        } else {
            error_log("G-Engine: API kursu istifadə olunur: {$api_rate}");
            $final_rate = $api_rate;
        }
        
        // Кэшируем на 1 час
        set_transient($cache_key, $final_rate, HOUR_IN_SECONDS);
        
        return $final_rate;
    }
    
    private function get_current_currency() {
        // Проверяем WooCommerce мультивалюту
        if (function_exists('get_woocommerce_currency')) {
            return get_woocommerce_currency();
        }
        
        // Проверяем WPML Currency Switcher
        if (defined('WCML_VERSION') && function_exists('wcml_get_woocommerce_currency_option')) {
            global $woocommerce_wpml;
            if (isset($woocommerce_wpml->multi_currency)) {
                return $woocommerce_wpml->multi_currency->get_client_currency();
            }
        }
        
        // Fallback
        return 'AZN';
    }
    
    private function format_price_with_discount($price) {
        $discount = floatval(get_option('gengine_fake_discount', 0));
        $currency = $this->get_currency_symbol();
        
        if ($discount <= 0) {
            return '<span class="gengine-final-price">' . number_format($price, 2) . ' ' . $currency . '</span>';
        }
        
        // Фейковая скидка: текущая цена (уже с наценкой) - это цена ПОСЛЕ скидки.
        // Рассчитываем "старую" цену так, чтобы текущая была на X% меньше.
        $old_price = $price / (1 - ($discount / 100));
        
        return '<span class="gengine-old-price">' . number_format($old_price, 2) . ' ' . $currency . '</span> ' .
               '<span class="gengine-final-price">' . number_format($price, 2) . ' ' . $currency . '</span>';
    }
    
    private function get_currency_symbol() {
        $currency = $this->get_current_currency();
        $symbols = array(
            'AZN' => 'AZN',
            'USD' => '$',
            'EUR' => '€',
            'RUB' => '₽',
            'TRY' => '₺',
            'GBP' => '£'
        );
        return isset($symbols[$currency]) ? $symbols[$currency] : $currency;
    }

    private function get_service_image($item_id, $api_img_url = '') {
        $custom_images = get_option('gengine_custom_images', array());
        
        // Проверяем наличие кастомного изображения
        if (isset($custom_images[$item_id]) && !empty($custom_images[$item_id])) {
            $attachment_id = intval($custom_images[$item_id]);
            
            // Проверяем разные размеры
            $url = wp_get_attachment_image_url($attachment_id, 'medium');
            if (!$url) {
                $url = wp_get_attachment_image_url($attachment_id, 'full');
            }
            if (!$url) {
                $url = wp_get_attachment_url($attachment_id);
            }
            
            if ($url) {
                error_log("G-Engine: Используется кастомное изображение для item_id={$item_id}: {$url}");
                return $url;
            } else {
                error_log("G-Engine: Кастомное изображение attachment_id={$attachment_id} не найдено для item_id={$item_id}");
            }
        }
        
        // Используем изображение из API или placeholder
        return !empty($api_img_url) ? $api_img_url : 'https://via.placeholder.com/150?text=Sekil+Yoxdur';
    }

    public function recharge_shortcode() { return $this->render_shop('recharge'); }
    public function gift_cards_shortcode() { return $this->render_shop('gift'); }
    public function shop_shortcode() { return $this->render_shop('all'); }

    private function render_shop($type) {
        if (!class_exists('WooCommerce')) return '<b>WooCommerce quraşdırın</b>';
        ob_start();
        echo '<div id="gengine-shop-container" class="gengine-shop-' . $type . '">' . $this->render_catalog($type) . '</div>';
        echo '<div id="gengine-modal" class="gengine-modal"><div class="gengine-modal-content"><span class="gengine-close">&times;</span><div id="gengine-modal-body"></div></div></div>';
        echo $this->styles() . $this->scripts();
        return ob_get_clean();
    }

    private function render_catalog($type) {
        $items = array();
        
        if ($type === 'recharge' || $type === 'all') {
            $items = array_merge($items, $this->get_all_items('/recharge/services'));
        }
        
        if ($type === 'gift' || $type === 'all') {
            $items = array_merge($items, $this->get_all_items('/shop/products'));
        }
        
        if (empty($items)) {
            return '<div style="padding: 40px; text-align: center;">
                <h3>Kataloq boşdur</h3>
                <p>Admin paneldə API parametrlərini yoxlayın</p>
            </div>';
        }
        
        $html = '<div class="gengine-grid">';
        foreach ($items as $item) {
            $is_gift = !isset($item['params']) && !isset($item['type']);
            $img = $this->get_service_image($item['id'], isset($item['image_url']) ? $item['image_url'] : '');
            $stock_status = '';
            if (isset($item['in_stock'])) {
                if ($item['in_stock']) {
                    $stock_status = '<div class="gengine-stock status-in">Stokda</div>';
                } else {
                    $stock_status = '<div class="gengine-stock status-out">Stokda yoxdur</div>';
                }
            }
            
            $html .= '<div class="gengine-card" data-id="' . intval($item['id']) . '" data-source="' . ($is_gift ? 'gift' : 'recharge') . '" data-img="' . esc_attr($img) . '">
                <img src="' . esc_url($img) . '" class="gengine-card-img">
                <div class="gengine-card-title">' . esc_html($item['name']) . '</div>
                ' . $stock_status . '
            </div>';
        }
        return $html . '</div>';
    }

	    public function ajax_get_service() {
            error_log("G-Engine: AJAX call for ID: " . $_POST['id'] . " Source: " . $_POST['source']);
	        $id = intval($_POST['id']);
	        $source = sanitize_text_field($_POST['source']);
        
        $service = null;
        if ($source === 'gift') {
            $items = $this->get_all_items('/shop/products');
            
            foreach ($items as $s) {
                if ($s['id'] == $id) {
                    $service = $s;
                    break;
                }
            }
            
            if ($service) {
                $denoms_data = $this->request("/shop/denominations/{$id}");
                
                error_log("G-Engine: Структура ответа для product_id $id: " . print_r($denoms_data, true));
                
                // Проверяем разные варианты структуры ответа
                if (isset($denoms_data['data']['items']) && !empty($denoms_data['data']['items'])) {
                    $service['denominations'] = $denoms_data['data']['items'];
                    error_log("G-Engine: Найдено " . count($service['denominations']) . " номиналов в data->items");
                } elseif (isset($denoms_data['items']) && !empty($denoms_data['items'])) {
                    $service['denominations'] = $denoms_data['items'];
                    error_log("G-Engine: Найдено " . count($service['denominations']) . " номиналов в items");
                } elseif (isset($denoms_data['data']) && is_array($denoms_data['data']) && !empty($denoms_data['data'])) {
                    // Возможно данные прямо в data
                    $service['denominations'] = $denoms_data['data'];
                    error_log("G-Engine: Найдено " . count($service['denominations']) . " номиналов в data");
                } elseif (is_array($denoms_data) && !empty($denoms_data) && isset($denoms_data[0])) {
                    // Возможно это массив напрямую
                    $service['denominations'] = $denoms_data;
                    error_log("G-Engine: Найдено " . count($service['denominations']) . " номиналов в корне массива");
                } else {
                    $service['denominations'] = array();
                    error_log("G-Engine: ОШИБКА - $id məhsulu üçün nominasiyalar tapılmadı. Полный ответ: " . json_encode($denoms_data));
                }
                
                $service['type'] = 'fixed';
            }
        } else {
            $items = $this->get_all_items('/recharge/services');
            foreach ($items as $s) {
                if ($s['id'] == $id) {
                    $service = $s;
                    break;
                }
            }
        }

        if (!$service) wp_send_json_error('Məhsul tapılmadı');
        
        $img = $this->get_service_image($service['id'], isset($service['image_url']) ? $service['image_url'] : '');
        ob_start();
        ?>
        <div class="gengine-service-detail">
            <div class="gengine-header">
                <img src="<?php echo esc_url($img); ?>" class="gengine-detail-icon">
                <h2><?php echo esc_html($service['name']); ?></h2>
            </div>
            
            <div class="gengine-main-content">
                <div class="gengine-left-col">
                    <h3>Nominal seçin</h3>
                    <div class="gengine-denoms">
                        <?php if ($service['type'] === 'fixed' && !empty($service['denominations'])): ?>
                            <?php foreach ($service['denominations'] as $d): 
                                // Проверяем что есть необходимые поля
                                if (!isset($d['id']) || !isset($d['name']) || !isset($d['price'])) {
                                    error_log("G-Engine: Пропущен номинал с неправильной структурой: " . json_encode($d));
                                    continue;
                                }
                                $price = $this->azn_price($d['price']); 
                            ?>
	                                <div class="gengine-denom-row" data-id="<?php echo $d['id']; ?>" data-name="<?php echo esc_attr($d['name']); ?>" data-price="<?php echo $price; ?>" data-source="<?php echo $source; ?>">
	                                    <div class="denom-info">
	                                        <span class="denom-name"><?php echo esc_html($d['name']); ?></span>
	                                        <?php 
	                                        // Статус товара между названием и ценой
	                                        if (isset($d['stock'])) {
	                                            if ($d['stock'] > 0) {
	                                                echo '<span class="denom-stock-status status-in">Stokda</span>';
	                                            } else {
	                                                echo '<span class="denom-stock-status status-out">Stokda yoxdur</span>';
	                                            }
	                                        } else {
                                                // Если API не прислал stock, но это Gift Card, обычно они в наличии
                                                echo '<span class="denom-stock-status status-in">Stokda</span>';
                                            }
	                                        ?>
	                                    </div>
	                                    <div class="denom-price"><?php echo $this->format_price_with_discount($price); ?></div>
	                                </div>
                            <?php endforeach; ?>
                        <?php elseif ($service['type'] === 'unfixed'): ?>
                            <div class="gengine-input-group">
                                <label>Məbləğ (USD):</label>
                                <input type="number" id="gengine_quantity" min="1" step="0.01" class="gengine-input">
                            </div>
                        <?php else: ?>
                            <p style="color: #d63638; padding: 20px; background: #fff; border: 1px solid #d63638; border-radius: 6px;">
                                <strong>Paket tapılmadı</strong><br>
                                <small style="display: block; margin-top: 10px; color: #666;">
                                    Məhsul ID: <?php echo $service['id']; ?><br>
                                    Tip: <?php echo isset($service['type']) ? $service['type'] : 'təyin edilməyib'; ?><br>
                                    Nominallar sayı: <?php echo isset($service['denominations']) ? count($service['denominations']) : 0; ?><br>
                                    Debug: PHP error log-a baxın
                                </small>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="gengine-right-col">
                    <!-- Скрытая форма ввода данных (для fixed) или видимая (для unfixed) -->
                    <div id="gengine-input-form" style="display: <?php echo ($service['type'] === 'unfixed') ? 'block' : 'none'; ?>;">
                        <?php if ($source !== 'gift'): ?>
                        <div class="gengine-player-data">
                            <h3>Hesab məlumatları</h3>
                            <div class="gengine-input-group">
                                <input type="text" id="gengine_account" placeholder="Oyunçu İD" class="gengine-input">
                            </div>
			                            <?php 
                                    $params = !empty($service['params']) ? $service['params'] : (!empty($service['extra_params']) ? $service['extra_params'] : array());
                                    
                                    if (!empty($params)): foreach ($params as $param): 
	                                    $key = isset($param['param_key']) ? $param['param_key'] : (isset($param['key']) ? $param['key'] : '');
	                                    $type = isset($param['param_type']) ? $param['param_type'] : (isset($param['type']) ? $param['type'] : 'String');
                                        $options = isset($param['options']) ? $param['options'] : (isset($param['values']) ? $param['values'] : array());
	                                    
	                                    if (strtolower($key) === 'account' || empty($key)) continue; 
		                                ?>
			                                <div class="gengine-input-group">
			                                    <label><?php echo esc_html($key); ?></label>
			                                    <?php if ((strtolower($type) === 'select' || !empty($options)) && is_array($options)): ?>
			                                        <select class="gengine-extra-param gengine-input" data-key="<?php echo esc_attr($key); ?>">
		                                                <option value=""><?php echo esc_html($key); ?> seçin</option>
			                                            <?php foreach ($options as $opt_key => $opt_val): 
                                                            $opt_name = is_array($opt_val) ? (isset($opt_val['name']) ? $opt_val['name'] : $opt_val) : $opt_val;
                                                            $opt_value = is_array($opt_val) ? (isset($opt_val['value']) ? $opt_val['value'] : $opt_key) : $opt_key;
                                                            if (!is_array($opt_val) && is_string($opt_key) && !is_numeric($opt_key)) { $opt_value = $opt_key; $opt_name = $opt_val; }
                                                        ?>
			                                                <option value="<?php echo esc_attr($opt_value); ?>"><?php echo esc_html($opt_name); ?></option>
			                                            <?php endforeach; ?>
		                                        </select>
			                                    <?php else: ?>
			                                        <input type="text" class="gengine-extra-param gengine-input" data-key="<?php echo esc_attr($key); ?>" placeholder="<?php echo esc_attr($key); ?> daxil edin">
			                                    <?php endif; ?>
			                                </div>
			                            <?php endforeach; endif; ?>
                        </div>
                        <?php else: ?>
                        <div class="gengine-player-data">
                            <p style="font-size: 14px; color: #666;">Bu məhsul ödənişdən sonra aktivasiya kodu şəklində veriləcək.</p>
                            <input type="hidden" id="gengine_account" value="GiftCard">
                        </div>
                        <?php endif; ?>
                        
                        <!-- Кнопка добавления в корзину -->
                        <div class="gengine-summary-card">
                            <div class="summary-price" id="summary-price">0.00 <?php echo $this->get_currency_symbol(); ?></div>
                            <button id="gengine-add-cart-btn" class="gengine-main-btn" data-service-id="<?php echo $service['id']; ?>" data-service-name="<?php echo esc_attr($service['name']); ?>">
                                SƏBƏTƏ ƏLAVƏ ET
                            </button>
                        </div>
                    </div>
                    
                    <!-- Сообщение о выборе номинала (только для fixed) -->
                    <div id="gengine-select-hint" class="gengine-select-hint" style="display: <?php echo ($service['type'] === 'fixed') ? 'block' : 'none'; ?>;">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M9 11l3 3L22 4"></path>
                            <path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"></path>
                        </svg>
                        <h3>Paket seçin</h3>
                        <p>Davam etmək üçün paket seçin</p>
                    </div>
                </div>
            </div>
            <div id="gengine-modal-msg"></div>
        </div>
        <?php
        wp_send_json_success(ob_get_clean());
    }

    public function ajax_add_to_cart() {
        $service_id = intval($_POST['service_id']);
        $service_name = sanitize_text_field($_POST['service_name']);
        $account = sanitize_text_field($_POST['account']);
        $price = floatval($_POST['price']);
        $denom_name = isset($_POST['denom_name']) ? sanitize_text_field($_POST['denom_name']) : '';
        $extra_params = isset($_POST['extra_params']) ? $_POST['extra_params'] : array();
        $product_img = isset($_POST['product_img']) ? sanitize_text_field($_POST['product_img']) : '';

        if (empty($account)) wp_send_json_error('Oyunçu ID-ni daxil edin');
        if ($price <= 0) wp_send_json_error('Paket seçin');

        $product_id = $this->get_or_create_virtual_product();
        $cart_item_data = array(
            'gengine_data' => array(
                'service_id' => $service_id,
                'service_name' => $service_name,
                'denom_name' => $denom_name,
                'account' => $account,
                'extra_params' => $extra_params,
                'custom_price' => $price,
                'product_img' => $product_img
            )
        );
        WC()->cart->add_to_cart($product_id, 1, 0, array(), $cart_item_data);
        wp_send_json_success('Səbətə əlavə edildi!');
    }
    
    public function ajax_sync_products() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('İcazə yoxdur');
        }
        
        $recharge_items = $this->get_all_items('/recharge/services');
        $gift_items = $this->get_all_items('/shop/products');
        $all_items = array_merge($recharge_items, $gift_items);
        
        if (empty($all_items)) {
            wp_send_json_error('Məhsullar tapılmadı. API parametrlərini yoxlayın.');
        }
        
        $created = 0;
        $updated = 0;
        
        foreach ($all_items as $item) {
            $is_gift = !isset($item['params']) && !isset($item['type']);
            
            // Проверяем существует ли пост
            $existing = get_posts(array(
                'post_type' => 'gengine_product',
                'meta_key' => '_gengine_id',
                'meta_value' => $item['id'],
                'posts_per_page' => 1
            ));
            
            $img = $this->get_service_image($item['id'], isset($item['image_url']) ? $item['image_url'] : '');
            
            // Получаем минимальную цену для описания
            $min_price = 0;
            if ($is_gift) {
                $denoms_data = $this->request("/shop/denominations/{$item['id']}");
                
                // Пробуем разные варианты структуры
                $denoms = array();
                if (isset($denoms_data['data']['items']) && !empty($denoms_data['data']['items'])) {
                    $denoms = $denoms_data['data']['items'];
                } elseif (isset($denoms_data['items']) && !empty($denoms_data['items'])) {
                    $denoms = $denoms_data['items'];
                } elseif (isset($denoms_data['data']) && is_array($denoms_data['data']) && !empty($denoms_data['data'])) {
                    $denoms = $denoms_data['data'];
                } elseif (is_array($denoms_data) && !empty($denoms_data) && isset($denoms_data[0])) {
                    $denoms = $denoms_data;
                }
                
                if (!empty($denoms)) {
                    $prices = array();
                    foreach ($denoms as $d) {
                        if (isset($d['price'])) {
                            $prices[] = $this->azn_price($d['price']);
                        }
                    }
                    if (!empty($prices)) {
                        $min_price = min($prices);
                    }
                }
            }
            
            $post_data = array(
                'post_type' => 'gengine_product',
                'post_title' => $item['name'],
                'post_content' => $is_gift ? 'Hədiyyə kartı - ödənişdən sonra aktivasiya kodu veriləcək.' : 'Oyun balansı artırımı.',
                'post_status' => 'publish'
            );
            
            if ($existing) {
                // Обновляем существующий
                $post_data['ID'] = $existing[0]->ID;
                wp_update_post($post_data);
                $post_id = $existing[0]->ID;
                $updated++;
            } else {
                // Создаем новый
                $post_id = wp_insert_post($post_data);
                $created++;
            }
            
            // Сохраняем мета-данные
            update_post_meta($post_id, '_gengine_id', $item['id']);
            update_post_meta($post_id, '_gengine_type', $is_gift ? 'gift' : 'recharge');
            update_post_meta($post_id, '_gengine_image', $img);
            if ($min_price > 0) {
                update_post_meta($post_id, '_gengine_price', $min_price);
            }
            
            // Устанавливаем featured image если есть кастомное изображение
            $custom_images = get_option('gengine_custom_images', array());
            if (isset($custom_images[$item['id']]) && !empty($custom_images[$item['id']])) {
                set_post_thumbnail($post_id, $custom_images[$item['id']]);
            }
        }
        
        wp_send_json_success("Yaradıldı: $created, Yeniləndi: $updated məhsul");
    }

    private function get_or_create_virtual_product() {
        $args = array('post_type' => 'product', 'meta_key' => '_gengine_virtual', 'posts_per_page' => 1);
        $products = get_posts($args);
        if ($products) return $products[0]->ID;
        $product = new WC_Product_Simple();
        $product->set_name('G-Engine Məhsul');
        $product->set_status('publish');
        $product->set_catalog_visibility('hidden');
        $product->set_virtual(true);
        $product->set_price(0);
        $product->save();
        update_post_meta($product->get_id(), '_gengine_virtual', 'yes');
        return $product->get_id();
    }

    public function before_calculate_totals($cart) {
        if (is_admin() && !defined('DOING_AJAX')) return;
        foreach ($cart->get_cart() as $item) {
            if (isset($item['gengine_data']['custom_price'])) {
                $item['data']->set_price($item['gengine_data']['custom_price']);
            }
        }
    }

    public function change_cart_item_name($name, $cart_item, $cart_item_key) {
        if (isset($cart_item['gengine_data'])) {
            $data = $cart_item['gengine_data'];
            return $data['service_name'] . ($data['denom_name'] ? ' - ' . $data['denom_name'] : '');
        }
        return $name;
    }
    
    public function change_removed_item_name($name, $cart_item) {
        if (isset($cart_item['gengine_data'])) {
            $data = $cart_item['gengine_data'];
            return $data['service_name'] . ($data['denom_name'] ? ' - ' . $data['denom_name'] : '');
        }
        return $name;
    }

    public function cart_item_thumbnail($image, $cart_item, $cart_item_key) {
        if (isset($cart_item['gengine_data']['product_img']) && !empty($cart_item['gengine_data']['product_img'])) {
            $img_url = $cart_item['gengine_data']['product_img'];
            return '<img src="' . esc_url($img_url) . '" class="attachment-woocommerce_thumbnail" style="border-radius: 6px;">';
        }
        return $image;
    }

	    public function get_item_data($item_data, $cart_item) {
	        if (isset($cart_item['gengine_data'])) {
	            $data = $cart_item['gengine_data'];
	            if ($data['account'] !== 'GiftCard') {
	                $item_data[] = array('name' => 'Hesab', 'value' => $data['account']);
	            }
                if (!empty($data['extra_params'])) {
                    foreach ($data['extra_params'] as $k => $v) {
                        if (!empty($v)) $item_data[] = array('name' => $k, 'value' => $v);
                    }
                }
	        }
	        return $item_data;
	    }

	    public function add_order_item_meta($item, $cart_item_key, $values, $order) {
	        if (isset($values['gengine_data'])) {
	            $data = $values['gengine_data'];
	            if ($data['account'] !== 'GiftCard') {
	                $item->add_meta_data('Hesab', $data['account']);
	            }
                if (!empty($data['extra_params'])) {
                    foreach ($data['extra_params'] as $k => $v) {
                        if (!empty($v)) $item->add_meta_data($k, $v);
                    }
                }
	            $item->set_name($data['service_name'] . ($data['denom_name'] ? ' - ' . $data['denom_name'] : ''));
	        }
	    }

    private function styles() {
        return '<style>
        :root { --g-blue: #0067ed; }
        
        .gengine-grid { 
            display: grid; 
            grid-template-columns: repeat(6, 1fr); 
            gap: 20px; 
            padding: 20px; 
        }
        
        @media (max-width: 1400px) {
            .gengine-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }
        
        @media (max-width: 1200px) {
            .gengine-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .gengine-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
                padding: 15px;
            }
        }
        
        @media (max-width: 480px) {
            .gengine-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
                padding: 12px;
            }
        }
        
        .gengine-card { 
            background: #fff; 
            border-radius: 6px; 
            padding: 15px; 
            text-align: center; 
            cursor: pointer; 
            transition: 0.3s; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.08); 
            border: 1px solid #e8e8e8;
        }
        
        @media (max-width: 768px) {
            .gengine-card {
                padding: 12px;
            }
        }
        
        .gengine-card:hover { 
            transform: translateY(-5px); 
            box-shadow: 0 5px 20px rgba(0, 103, 237, 0.15); 
            border-color: var(--g-blue);
        }
        
        .gengine-card-img { 
            width: 100%; 
            height: 120px; 
            object-fit: contain; 
            margin-bottom: 10px; 
            border-radius: 6px; 
        }
        
        @media (max-width: 768px) {
            .gengine-card-img {
                height: 100px;
            }
        }
        
        @media (max-width: 480px) {
            .gengine-card-img {
                height: 80px;
                margin-bottom: 8px;
            }
        }
        
        .gengine-card-title { 
            font-weight: 600; 
            color: #333; 
            font-size: 14px; 
            margin-bottom: 5px;
        }
        
        .gengine-stock {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            padding: 2px 8px;
            border-radius: 4px;
            display: inline-block;
        }
        
        .status-in {
            background: #e6fcf5;
            color: #0ca678;
        }
        
	        .status-out {
	            background: #fff5f5;
	            color: #fa5252;
	        }
            
            .denom-stock-status {
                font-size: 10px;
                font-weight: 700;
                text-transform: uppercase;
                padding: 2px 6px;
                border-radius: 4px;
                display: inline-block;
                margin-top: 4px;
            }
            .denom-stock-status.status-in { background: #e6fcf5; color: #0ca678; }
            .denom-stock-status.status-out { background: #fff5f5; color: #fa5252; }
        
        @media (max-width: 768px) {
            .gengine-card-title {
                font-size: 13px;
            }
        }
        
        @media (max-width: 480px) {
            .gengine-card-title {
                font-size: 12px;
            }
        }
        
        .gengine-modal { 
            display: none; 
            position: fixed; 
            z-index: 9999; 
            left: 0; 
            top: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.6); 
            overflow-y: auto; 
        }
        
        .gengine-modal-content { 
            background: #fff; 
            margin: 3% auto; 
            border-radius: 12px; 
            width: 90%; 
            max-width: 900px; 
            position: relative; 
            animation: gSlide 0.3s; 
        }
        
        @media (max-width: 768px) {
            .gengine-modal-content {
                width: 95%;
                margin: 5% auto;
            }
        }
        
        @media (max-width: 480px) {
            .gengine-modal-content {
                width: 100%;
                margin: 0;
                border-radius: 0;
                min-height: 100vh;
            }
        }
        
        @keyframes gSlide { 
            from { transform: translateY(-30px); opacity: 0; } 
            to { transform: translateY(0); opacity: 1; } 
        }
        
        .gengine-close { 
            position: absolute; 
            right: 20px; 
            top: 15px; 
            font-size: 28px; 
            cursor: pointer; 
            color: #999; 
            z-index: 10; 
            transition: 0.2s;
        }
        
        .gengine-close:hover {
            color: #333;
        }
        
        .gengine-service-detail { 
            padding: 30px; 
        }
        
        @media (max-width: 768px) {
            .gengine-service-detail {
                padding: 20px;
            }
        }
        
        @media (max-width: 480px) {
            .gengine-service-detail {
                padding: 15px;
            }
        }
        
        .gengine-header { 
            display: flex; 
            align-items: center; 
            gap: 15px; 
            margin-bottom: 25px; 
            padding-bottom: 20px;
            border-bottom: 1px solid #e8e8e8;
        }
        
        .gengine-detail-icon { 
            width: 50px; 
            height: 50px; 
            border-radius: 6px; 
            object-fit: cover; 
        }
        
        .gengine-header h2 {
            margin: 0;
            color: #333;
            font-size: 22px;
        }
        
        .gengine-main-content { 
            display: flex; 
            gap: 30px; 
        }
        
        .gengine-left-col { 
            flex: 1.5; 
        }
        
        .gengine-right-col { 
            flex: 1; 
        }
        
        .gengine-left-col h3,
        .gengine-right-col h3 {
            font-size: 16px;
            margin-bottom: 15px;
            color: #333;
        }
        
        .gengine-denoms { 
            border: 1px solid #e8e8e8; 
            border-radius: 6px; 
            overflow: hidden; 
            margin-bottom: 25px; 
        }
        
        .gengine-denom-row { 
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            padding: 14px 16px; 
            border-bottom: 1px solid #e8e8e8; 
            cursor: pointer; 
            transition: 0.2s; 
        }
        
        .gengine-denom-row:last-child {
            border-bottom: none;
        }
        
        .gengine-denom-row:hover { 
            background: #f5f9ff; 
        }
        
        .gengine-denom-row.active { 
            background: #e8f2ff; 
            border-left: 4px solid var(--g-blue); 
        }
        
        .denom-name { 
            display: block; 
            font-weight: 600; 
            font-size: 14px; 
            color: #333;
        }
        
        .denom-stock {
            flex: 1;
            text-align: center;
        }
        
        .stock-badge {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            padding: 3px 10px;
            border-radius: 4px;
            display: inline-block;
        }
        
        .stock-badge.in-stock {
            background: #e6fcf5;
            color: #0ca678;
        }
        
        .stock-badge.out-of-stock {
            background: #fff5f5;
            color: #fa5252;
        }
        
        .denom-sub { 
            font-size: 12px; 
            color: #888; 
        }
        
        .denom-stock-status {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            padding: 2px 8px;
            border-radius: 4px;
            display: inline-block;
            margin-top: 5px;
        }
        
        .denom-stock-status.status-in {
            background: #e6fcf5;
            color: #0ca678;
        }
        
        .denom-stock-status.status-out {
            background: #fff5f5;
            color: #fa5252;
        }
        
        .price-val { 
            font-weight: 700; 
            font-size: 16px; 
            color: var(--g-blue);
        }
        
        .gengine-old-price {
            font-size: 11px !important;
            color: #999 !important;
            text-decoration: line-through !important;
            margin-right: 8px !important;
            opacity: 0.8 !important;
            display: inline-block !important;
        }
        
        .gengine-final-price {
            font-weight: 700 !important;
            font-size: 17px !important;
            color: #dc3545 !important;
            display: inline-block !important;
        }
        
        .denom-price {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        
        .gengine-player-data { 
            background: #f8f9fa; 
            padding: 20px; 
            border-radius: 6px; 
            margin-bottom: 20px;
            border: 1px solid #e8e8e8;
        }
        
        .gengine-input { 
            width: 100%; 
            padding: 12px 14px; 
            border: 1px solid #d0d5dd; 
            border-radius: 6px; 
            margin-top: 5px; 
            font-size: 14px; 
            transition: 0.2s;
            background: #fff;
        }
        
        .gengine-input:focus {
            outline: none;
            border-color: var(--g-blue);
            box-shadow: 0 0 0 3px rgba(0, 103, 237, 0.1);
        }
        
        .gengine-input-group { 
            margin-bottom: 15px; 
        }
        
        .gengine-input-group label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
            font-weight: 500;
            color: #344054;
        }
        
        .gengine-summary-card { 
            background: #fff; 
            border: 1px solid #e8e8e8; 
            padding: 25px; 
            border-radius: 6px; 
            text-align: center; 
            position: sticky; 
            top: 20px; 
        }
        
        .summary-price { 
            font-size: 32px; 
            font-weight: 700; 
            margin-bottom: 20px; 
            color: var(--g-blue);
        }
        
        .gengine-main-btn { 
            background: var(--g-blue); 
            color: #fff; 
            border: none; 
            width: 100%; 
            padding: 14px; 
            border-radius: 6px; 
            font-weight: 700; 
            cursor: pointer; 
            font-size: 14px; 
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: 0.2s;
        }
        
        .gengine-main-btn:hover {
            background: #0052bd;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 103, 237, 0.3);
        }
        
        .gengine-main-btn:active {
            transform: translateY(0);
        }
        
        .gengine-main-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
        }
        
        #gengine-modal-msg { 
            margin-top: 15px; 
            text-align: center; 
        }
        
        .msg-success { 
            color: #28a745; 
            font-weight: 600; 
            padding: 12px;
            background: #d4edda;
            border-radius: 6px;
            border: 1px solid #c3e6cb;
        }
        
        .msg-success a {
            color: var(--g-blue);
            text-decoration: none;
            font-weight: 700;
        }
        
        .gengine-select-hint {
            background: #f8f9fa;
            border: 2px dashed #d1d5db;
            border-radius: 12px;
            padding: 40px 30px;
            text-align: center;
            color: #6b7280;
        }
        
        .gengine-select-hint svg {
            color: #d1d5db;
            margin: 0 auto 20px;
            display: block;
        }
        
        .gengine-select-hint h3 {
            color: #374151;
            font-size: 18px;
            margin-bottom: 8px;
        }
        
        .gengine-select-hint p {
            font-size: 14px;
            margin: 0;
        }
        
        #gengine-input-form {
            animation: fadeInUp 0.3s ease-out;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @media (max-width: 768px) { 
            .gengine-main-content { 
                flex-direction: column; 
            }
            
            .gengine-summary-card {
                position: relative;
                top: 0;
            }
            
            .gengine-main-btn {
                padding: 16px;
                font-size: 15px;
            }
            
            .gengine-header h2 {
                font-size: 18px;
            }
            
            .gengine-denom-row {
                padding: 12px 14px;
            }
        }
        
        @media (max-width: 480px) {
            .gengine-main-btn {
                padding: 14px;
                font-size: 13px;
            }
            
            .summary-price {
                font-size: 28px;
            }
            
            .gengine-input {
                font-size: 15px;
            }
        }
        </style>';
    }

    private function scripts() {
        return '<script>
        jQuery(document).ready(function($) {
            var selectedDenom = null;
            var currentProductImg = "";
            
            $(document).on("click", ".gengine-card", function() {
                var id = $(this).data("id");
                var source = $(this).data("source");
                currentProductImg = $(this).data("img");
                
                $("#gengine-modal").show();
                $("#gengine-modal-body").html("<p style=\'text-align:center;padding:50px;\'>Yüklənir...</p>");
                
                $.post("' . admin_url('admin-ajax.php') . '", { 
                    action: "gengine_get_service", 
                    id: id, 
                    source: source 
                }, function(res) {
                    if(res.success) { 
                        $("#gengine-modal-body").html(res.data); 
                        selectedDenom = null; 
                    } else { 
                        $("#gengine-modal-body").html("<p style=\'padding:20px;color:red;\'>" + res.data + "</p>"); 
                    }
                });
            });
            
            $(".gengine-close, .gengine-modal").on("click", function(e) { 
                if(e.target == this) $("#gengine-modal").hide(); 
            });
            
            $(document).on("click", ".gengine-denom-row", function() {
                $(".gengine-denom-row").removeClass("active");
                $(this).addClass("active");
                selectedDenom = { 
                    id: $(this).data("id"), 
                    name: $(this).data("name"), 
                    price: $(this).data("price"),
                    source: $(this).data("source")
                };
                
                // Копируем HTML с ценой из выбранного номинала
                var priceHtml = $(this).find(".denom-price").html();
                $("#summary-price").html(priceHtml);
                
                // Показать форму ввода данных
                $("#gengine-select-hint").hide();
                $("#gengine-input-form").show();
                
                // Для gift карт скрыть поле account
                if(selectedDenom.source === "gift") {
                    $("#gengine_account").val("GiftCard");
                }
            });
            
            // Обработка изменения суммы для unfixed товаров
            $(document).on("input", "#gengine_quantity", function() {
                var qty = $(this).val();
                if(qty && parseFloat(qty) > 0) {
                    var markup = ' . get_option('gengine_markup', 15) . ';
                    var rate = ' . $this->get_exchange_rate() . ';
                    var price = (parseFloat(qty) * rate * (1 + markup / 100)).toFixed(2);
                    $("#summary-price").html("<span class=\'gengine-final-price\'>" + price + " ' . $this->get_currency_symbol() . '</span>");
                } else {
                    $("#summary-price").html("0.00 ' . $this->get_currency_symbol() . '");
                }
            });
            
            $(document).on("click", "#gengine-add-cart-btn", function() {
                var btn = $(this);
                var account = $("#gengine_account").val();
                
                if(!account) { 
                    alert("Oyunçu ID-ni daxil edin"); 
                    return; 
                }
                
                var price = 0, denomName = "";
                
                if(selectedDenom) { 
                    price = selectedDenom.price; 
                    denomName = selectedDenom.name; 
                } else if($("#gengine_quantity").length) {
                    var qty = $("#gengine_quantity").val();
                    if(!qty) { 
                        alert("Məbləği daxil edin"); 
                        return; 
                    }
                    var markup = ' . get_option('gengine_markup', 15) . ';
                    var rate = ' . $this->get_exchange_rate() . ';
                    price = (parseFloat(qty) * rate * (1 + markup / 100)).toFixed(2);
                } else { 
                    alert("Paket seçin"); 
                    return; 
                }
                
	                var extraParams = {};
                    var missingParam = false;
	                $(".gengine-extra-param").each(function() { 
                        var val = $(this).val();
                        var key = $(this).data("key");
                        if(!val) {
                            alert(key + " daxil edin və ya seçin");
                            missingParam = true;
                            return false;
                        }
	                    extraParams[key] = val; 
	                });
                    if(missingParam) return;
                
                btn.prop("disabled", true).text("...");
                
                $.post("' . admin_url('admin-ajax.php') . '", {
                    action: "gengine_add_to_cart",
                    service_id: btn.data("service-id"),
                    service_name: btn.data("service-name"),
                    denom_name: denomName,
                    account: account,
                    price: price,
                    extra_params: extraParams,
                    product_img: currentProductImg
                }, function(res) {
                    if(res.success) { 
                        $("#gengine-modal-msg").html("<p class=\'msg-success\'>" + res.data + "</p>"); 
                        setTimeout(function() {
                            window.location.href = "' . wc_get_cart_url() . '";
                        }, 800);
                    } else { 
                        alert(res.data); 
                    }
                    btn.prop("disabled", false).text("SƏBƏTƏ ƏLAVƏ ET");
                });
            });
        });
        </script>';
    }

    public function ajax_save_image() {
        if (!current_user_can('manage_options')) wp_send_json_error('Giriş qadağandır');
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'gengine_save_image')) wp_send_json_error('Təhlükəsizlik xətası');
        
        $product_id = sanitize_text_field($_POST['product_id']);
        $image_id = !empty($_POST['image_id']) ? intval($_POST['image_id']) : 0;
        
        $custom_images = get_option('gengine_custom_images', array());
        if (!is_array($custom_images)) $custom_images = array();
        
        if ($image_id === 0) {
            unset($custom_images[$product_id]);
        } else {
            $custom_images[$product_id] = $image_id;
        }
        
        $updated = update_option('gengine_custom_images', $custom_images);
        
        if ($updated || get_option('gengine_custom_images') === $custom_images) {
            wp_send_json_success('Şəkil yadda saxlanıldı');
        } else {
            wp_send_json_error('Yadda saxlamaq mümkün olmadı');
        }
    }

    /**
     * G-Engine API Sifariş emalı
     */
    private function request($endpoint, $method = 'GET', $data = null) {
        $api_key = get_option('gengine_api_key');
        if (!$api_key) {
            error_log('G-Engine: API açarı konfiqurasiya edilməyib');
            return array();
        }
        
        $url = $this->api_url . $endpoint;
        $args = array(
            'method'  => $method,
            'headers' => array(
                'x-api-key' => $api_key,
                'Accept'    => 'application/json'
            ),
            'timeout'   => 30,
            'sslverify' => false
        );

        if ($data !== null) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = json_encode($data);
        }

        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            error_log('G-Engine API Xətası: ' . $response->get_error_message());
            return array();
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log("G-Engine API Sorğusu: $endpoint | Status: $status_code");
        
        $data = json_decode($body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('G-Engine JSON dekodlaşdırma xətası: ' . json_last_error_msg());
            return array();
        }
        
        if (isset($data['success']) && $data['success'] === false) {
            $message = isset($data['message']) ? $data['message'] : 'Naməlum API xətası';
            error_log("G-Engine API Xətası: $message");
            return array();
        }
        
        return $data;
    }

    public function process_gengine_order($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;

        if ($order->get_meta('_gengine_processed') === 'yes') return;

        $all_success = true;
        $error_messages = array();

        foreach ($order->get_items() as $item_id => $item) {
            $gengine_data = $item->get_meta('gengine_data');
            if (!$gengine_data) continue;

            $source = isset($gengine_data['source']) ? $gengine_data['source'] : (isset($gengine_data['account']) && $gengine_data['account'] === 'GiftCard' ? 'gift' : 'recharge');
            $service_id = $gengine_data['service_id'];
            
            if ($source === 'gift') {
                $api_res = $this->request('/shop/orders', 'POST', array(
                    'items' => array(array('id' => $service_id, 'quantity' => 1))
                ));

                if ($api_res && isset($api_res['success']) && $api_res['success']) {
                    $g_order_id = $api_res['data']['id'];
                    $pay_res = $this->request("/shop/orders/{$g_order_id}/pay", 'POST');
                    if ($pay_res && isset($pay_res['success']) && $pay_res['success']) {
                        $codes = array();
                        if (isset($pay_res['data']['products'])) {
                            foreach ($pay_res['data']['products'] as $p) {
                                foreach ($p['denominations'] as $d) {
                                    foreach ($d['items'] as $i) {
                                        if (isset($i['activation_code'])) $codes[] = $i['activation_code'];
                                    }
                                }
                            }
                        }
                        $order->add_order_note("Sifariş #{$g_order_id} tamamlandı. Kodlar: " . implode(', ', $codes));
                        $this->send_telegram("✅ <b>Sifariş Tamamlandı!</b>\n\nSifariş ID: #{$order_id}\nG-Engine ID: #{$g_order_id}\nMəhsul: {$item->get_name()}\nKodlar: " . implode(', ', $codes));
                    } else {
                        $all_success = false;
                        $msg = isset($pay_res['message']) ? $pay_res['message'] : 'Naməlum xəta';
                        $error_messages[] = "Gift Card (#{$service_id}): " . $msg;
                        $order->add_order_note("G-Engine Ödəniş Xətası: " . $msg);
                        $this->send_telegram("❌ <b>Ödəniş Xətası!</b>\n\nSifariş ID: #{$order_id}\nMəhsul: {$item->get_name()}\nXəta: {$msg}");
                    }
                } else {
                    $all_success = false;
                    $msg = isset($api_res['message']) ? $api_res['message'] : 'Sifariş yaradıla bilmədi';
                    $error_messages[] = "Gift Card (#{$service_id}): " . $msg;
                    $order->add_order_note("G-Engine Sifariş Xətası: " . $msg);
                }
            } else {
                $recharge_data = array(
                    'account' => $gengine_data['account'],
                    'amount' => isset($gengine_data['usd_amount']) ? $gengine_data['usd_amount'] : 0
                );
                if (!empty($gengine_data['extra_params'])) {
                    $recharge_data = array_merge($recharge_data, $gengine_data['extra_params']);
                }

                $api_res = $this->request("/recharge/orders/{$service_id}", 'POST', $recharge_data);
                if ($api_res && isset($api_res['success']) && $api_res['success']) {
                    $g_order_id = $api_res['data']['id'];
                    $pay_res = $this->request("/recharge/orders/{$g_order_id}/pay", 'POST');
                    if ($pay_res && isset($pay_res['success']) && $pay_res['success']) {
                        $order->add_order_note("Sifariş #{$g_order_id} tamamlandı.");
                        $this->send_telegram("✅ <b>Artırım Tamamlandı!</b>\n\nSifariş ID: #{$order_id}\nG-Engine ID: #{$g_order_id}\nMəhsul: {$item->get_name()}");
                    } else {
                        $all_success = false;
                        $msg = isset($pay_res['message']) ? $pay_res['message'] : 'Naməlum xəta';
                        $error_messages[] = "Artırım (#{$service_id}): " . $msg;
                        $order->add_order_note("G-Engine Artırım Ödəniş Xətası: " . $msg);
                        $this->send_telegram("❌ <b>Artırım Ödəniş Xətası!</b>\n\nSifariş ID: #{$order_id}\nMəhsul: {$item->get_name()}\nXəta: {$msg}");
                    }
                } else {
                    $all_success = false;
                    $msg = isset($api_res['message']) ? $api_res['message'] : 'Artırım sifarişi yaradıla bilmədi';
                    $error_messages[] = "Artırım (#{$service_id}): " . $msg;
                    $order->add_order_note("G-Engine Artırım Xətası: " . $msg);
                }
            }
        }

        if ($all_success) {
            $order->update_meta_data('_gengine_processed', 'yes');
            $order->save();
        } else {
            $order->update_status('on-hold', 'G-Engine API xətası səbəbindən sifariş gözləmədədir: ' . implode('; ', $error_messages));
        }
    }
}

new GEngineAZNShop();
